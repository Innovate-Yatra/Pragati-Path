document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('theme-toggle');
    const formToggleBtns = document.querySelectorAll('.toggle-btn');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const formTitle = document.getElementById('form-title');

    const loginFieldsContainer = document.getElementById('role-specific-login-fields');
    const signupFieldsContainer = document.getElementById('role-specific-signup-fields');

    // Theme Toggle
    themeToggle.addEventListener('change', () => {
        document.body.classList.toggle('dark-theme');
        document.body.classList.toggle('light-theme');
    });

    // Form Toggle (Login/Signup)
    function showForm(formType) {
        if (formType === 'login') {
            loginForm.classList.add('active');
            signupForm.classList.remove('active');
            formToggleBtns[0].classList.add('active');
            formToggleBtns[1].classList.remove('active');
        } else if (formType === 'signup') {
            signupForm.classList.add('active');
            loginForm.classList.remove('active');
            formToggleBtns[0].classList.remove('active');
            formToggleBtns[1].classList.add('active');
        }
    }

    window.showForm = showForm;

    // Role-Specific Fields
    function loadRoleSpecificFields(role) {
        if (role === 'admin') {
            formTitle.textContent = 'Admin Login';
            loginFieldsContainer.innerHTML = `
                <div class="form-group">
                    <label for="admin-code">Admin Code</label>
                    <input type="password" id="admin-code" name="admin-code" placeholder="Enter Admin Code" required>
                </div>
            `;
        } else if (role === 'faculty') {
            formTitle.textContent = 'Faculty Login';
            loginFieldsContainer.innerHTML = `
                <div class="form-group">
                    <label for="faculty-id">Faculty ID</label>
                    <input type="text" id="faculty-id" name="faculty-id" placeholder="Enter Faculty ID" required>
                </div>
            `;
        } else if (role === 'student') {
            formTitle.textContent = 'Student Login';
            loginFieldsContainer.innerHTML = `
                <div class="form-group">
                    <label for="roll-number">Roll Number</label>
                    <input type="text" id="roll-number" name="roll-number" placeholder="Enter Roll Number" required>
                </div>
            `;
        }
    }

    // Check URL for user role and load the respective form fields
    const params = new URLSearchParams(window.location.search);
    const role = params.get('role');

    if (role) {
        loadRoleSpecificFields(role);
    }

    // Initially display login form
    showForm('login');

    // Handle Login Form Submission and Redirection
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        // Simulate successful login (in a real app, you'd validate the credentials on the server)
        if (email && password) {
            alert('Login Successful');
            
            // Redirect based on the role
            if (role === 'admin') {
                window.location.href = 'admin-dashboard.html';
            } else if (role === 'faculty') {
                window.location.href = 'faculty-dashboard.html';
            } else if (role === 'student') {
                window.location.href = 'student-dashboard.html';
            } else {
                // Default redirection to a general dashboard
                window.location.href = 'dashboard.html';
            }
        } else {
            alert('Invalid credentials. Please try again.');
        }
    });
});

// Assuming role-based redirection logic in login.js
loginForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // Simulate login success
    if (email && password) {
        // Role-based redirection
        if (role === 'admin') {
            window.location.href = 'admin-dashboard.html';
        } else if (role === 'faculty') {
            window.location.href = 'faculty-dashboard.html';
        } else if (role === 'student') {
            window.location.href = 'student-dashboard.html';
        } else {
            window.location.href = 'dashboard.html';
        }
    } else {
        alert('Invalid login credentials.');
    }
});
