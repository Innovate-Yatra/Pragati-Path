const express = require("express");
const userController = require("../controllers/userController");
const userValidation = require("../middleware/userValidation");
const authMiddleware = require("../middleware/authMiddleware").authMiddleware;

const router = express.Router();

// Apply authMiddleware only to certain routes
router.use(authMiddleware);

// Get all users
router.get("/", userController.getAllUsers);

// Get user by ID
router.get("/:id", userController.getUserById);

// Create a new user
router.post("/", userValidation.validationCreateUser, userController.createUser);

// Update user by ID
router.patch("/:id", userValidation.validationUpdateUser, userController.updateUser);

// Delete user by ID
router.delete("/:id", userController.deleteUser);

module.exports = router;
